from setuptools import setup

setup(name='pa27_dataexplorer',
      version='0.1',
      description='A package for quick and easy data exploration and inspection',
      packages=['dataExplore'],
      zip_safe=False)
